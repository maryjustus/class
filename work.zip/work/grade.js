let ca1  = document.getElementById('First CA')
let ca2  = document.getElementById('Second CA')
let exam  = document.getElementById('Exam')
let total  = document.getElementById('Total')
let grade  = document.getElementById('Grade')

function checkResult(){
    let totalscore = Number(ca1.value) + Number(ca2.value) + Number(exam.value)
    total.value = totalscore

    if(totalscore>75){
        grade.value = 'A'
    } else if(totalscore>=60){
        grade.value = 'B'
    
    } else if(totalscore>=45){
        grade.value = 'C'
    } else{
        grade.value = 'D'
    }
}