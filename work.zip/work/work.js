let names = document.getElementById('name')
let msg = document.getElementById('msg')

function Greetigs(){
    let date = new Date()

    if(date.getHours() <12){
        msg.innerHTML = 'Good Morning ' + names.value
    }
    else if(date.getHours() <16){
        msg.innerHTML = 'Good Afternoon ' + names.value
    } else if(date.getHours() <24){
        msg.innerHTML = 'Good Evening ' + names.value
    }
    
}
